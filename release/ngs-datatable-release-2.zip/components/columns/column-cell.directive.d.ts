import { TemplateRef } from '@angular/core';
export declare class DataTableColumnCellDirective {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
}
