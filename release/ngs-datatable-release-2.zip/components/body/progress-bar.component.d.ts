export declare class ProgressBarComponent {
}
