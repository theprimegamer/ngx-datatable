"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require('./row-detail.directive'));
__export(require('./row-detail-template.directive'));
//# sourceMappingURL=index.js.map