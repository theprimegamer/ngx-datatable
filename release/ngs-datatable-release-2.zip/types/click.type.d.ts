export declare enum ClickType {
    single,
    double,
}
