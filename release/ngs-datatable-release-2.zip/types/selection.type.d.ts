export declare enum SelectionType {
    single,
    multi,
    multiClick,
    cell,
    checkbox,
}
