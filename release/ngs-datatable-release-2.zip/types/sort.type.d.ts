export declare enum SortType {
    single,
    multi,
}
