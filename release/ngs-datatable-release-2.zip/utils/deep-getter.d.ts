/**
 * Returns a deep object given a string. zoo['animal.type']
 * @param {object} obj
 * @param {string} path
 */
export declare function deepValueGetter(obj: Object, path: string): Object;
