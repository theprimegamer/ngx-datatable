export declare function getVendorPrefixedName(property: string): any;
