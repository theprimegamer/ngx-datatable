export declare function selectRows(selected: any[], row: any, comparefn: Function): any[];
export declare function selectRowsBetween(selected: any[], rows: any[], index: number, prevIndex: number, comparefn: Function): any[];
