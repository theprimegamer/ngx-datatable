export declare function translateXY(styles: any, x: number, y: number): void;
